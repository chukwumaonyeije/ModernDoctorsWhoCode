import { roundTrip } from './round-trip.mjs';
const timeout = setTimeout(() => {
  console.error('MCP round trip exceeded 20 seconds');
  process.exit(1);
}, 20_000);
try {
  console.log(JSON.stringify(await roundTrip(), null, 2));
  console.log('PASS: actual MCP stdio discovery and tool-call round trip');
} finally {
  clearTimeout(timeout);
}
