import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { Client } from '@modelcontextprotocol/client';
import { StdioClientTransport } from '@modelcontextprotocol/client/stdio';

// A real subprocess and JSON-RPC transport, not a direct handler invocation.
export async function roundTrip() {
  const client = new Client({ name: 'notebook-verifier', version: '0.1.0' });
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [fileURLToPath(new URL('../dist/local.js', import.meta.url))],
    stderr: 'pipe',
  });
  try {
    await client.connect(transport);
    const { tools } = await client.listTools();
    assert.deepEqual(tools.map(t => t.name).sort(), ['get_note', 'search_notes']);
    for (const tool of tools) {
      assert.equal(tool.annotations.readOnlyHint, true);
      assert.equal(tool.inputSchema.type, 'object');
    }
    async function call(name, args) {
      const response = await client.callTool({ name, arguments: args });
      assert.notEqual(response.isError, true);
      const text = JSON.parse(response.content.find(c => c.type === 'text').text);
      assert.deepEqual(text, response.structuredContent);
      return text;
    }
    const search = await call('search_notes', { query: 'journal-club', limit: 1 });
    assert.equal(search.total, 2);
    assert.equal(search.matches.length, 1);
    assert.equal(search.matches[0].id, 'synthetic-001');
    const detail = await call('get_note', { id: search.matches[0].id });
    assert.equal(detail.found, true);
    assert.equal(detail.note.source.provenance, 'synthetic');
    assert.ok(detail.note.limitations);
    assert.deepEqual((await call('search_notes', { query: 'zz-no-match' })).matches, []);
    assert.deepEqual(await call('get_note', { id: 'unknown' }), {
      notice: detail.notice, found: false, note: null,
    });
    // SDK tool validation errors are tool results, not successful empty searches.
    for (const [name, args] of [
      ['search_notes', { query: ' ' }],
      ['search_notes', { query: 'reading', limit: 11 }],
      ['search_notes', { query: 'reading', extra: true }],
      ['get_note', { id: '../../secret' }],
    ]) {
      const invalid = await client.callTool({ name, arguments: args });
      assert.equal(invalid.isError, true);
    }
    return { tools: tools.map(t => t.name), search, retrievedId: detail.note.id,
      checks: 'discovery, search, retrieval, no matches, missing ID, four invalid calls' };
  } finally {
    await client.close();
    await transport.close();
  }
}
