# Physician Research Notebook: Part 1 exercise

This public teaching snapshot accompanies MCP for Physician Developers, Part 1.
It contains three synthetic notes, two read-only MCP tools and ten tests.
No patient data, clinical recommendations, API keys or AI model calls are needed.

## Run locally

Install Node.js 22 LTS (22.19.0 or newer in that major) or 24 LTS, with npm.
Extract the ZIP, open a terminal in this folder, then run:

```powershell
npm ci
npm run check
npm run smoke
```

Expected: type-check and build succeed, all 10 tests pass, and the smoke client
prints PASS after actual MCP discovery and calls. The smoke search uses
journal-club with limit 1: total 2, first ID synthetic-001.

## Inspect the tools yourself

```powershell
npm run build
npx --yes @modelcontextprotocol/inspector@2.12.0 node dist/local.js
```

Keep the terminal running and open the local Inspector URL it prints. Connect
using stdio, command node, arguments dist/local.js. List tools, then call
search_notes with {"query":"critical-reading"}. Expect one match, synthetic-001.
Call get_note with {"id":"synthetic-001"}; expect found true and the full note.
The synthetic source fields are null because there is no publication to cite.
Stop Inspector with Ctrl+C when finished. Do not share its session token.

## Ten-minute test experiment

The critical-reading topic and matching test already exist in this snapshot.
Read src/data/notes.json and test/notebook.test.mjs. Temporarily remove only
critical-reading from the first note, save, and run npm run check. The matching
test should fail. Restore the topic and rerun: all 10 tests should pass.
Restart the Inspector connection after rebuilding so it loads the new fixture.
Do not add a duplicate topic or test.

Try get_note with {"id":"unknown"}: found false, note null. A blank search
query is invalid rather than an empty search result. Automated tests cover
both outcomes. Record what you actually observe.

Teach-back: who selected the action, who sent the request, and who retrieved
the note? Why does retrieval not verify the note's scientific validity?

## Scope

src/notebook.ts contains bounded search and retrieval; src/server.ts defines
MCP tools; src/local.ts starts the stdio server. stdout is reserved for protocol
messages. The fixture is loaded at startup. The server does not follow source
URLs or execute retrieved instructions. This is an educational local prototype,
not a clinical or production system. Cloudflare hosting is a later lesson.

Snapshot prepared 2026-10-25 from the verified Part 1 course implementation.
The original preparation repository remains private. Dependencies retain their
own licenses; no new blanket open-source license is granted by this snapshot.
