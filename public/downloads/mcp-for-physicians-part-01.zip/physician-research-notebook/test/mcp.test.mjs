import test from 'node:test';
import { roundTrip } from '../scripts/round-trip.mjs';

test('SDK client discovers and calls the compiled server over stdio', { timeout: 20_000 }, roundTrip);
