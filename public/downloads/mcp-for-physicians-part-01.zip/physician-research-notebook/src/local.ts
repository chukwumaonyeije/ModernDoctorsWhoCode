import { serveStdio } from '@modelcontextprotocol/server/stdio';
import notes from './data/notes.json' with { type: 'json' };
import { createNotebook } from './notebook.js';
import { createServer } from './server.js';

// stdout belongs to MCP. Any future diagnostics must go to stderr.
const notebook = createNotebook(notes);
serveStdio(() => createServer(notebook));
