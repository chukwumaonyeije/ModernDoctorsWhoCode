import { z } from 'zod';

export const searchInput = z.strictObject({
  query: z.string().trim().min(1).max(200),
  limit: z.number().int().min(1).max(10).default(5),
});
export const getInput = z.strictObject({
  id: z.string().trim().min(1).max(64).regex(/^[a-z0-9-]+$/),
});
const noteSchema = z.strictObject({
  id: getInput.shape.id,
  title: z.string().min(1).max(160),
  topics: z.array(z.string().min(1).max(60)).min(1).max(10),
  summary: z.string().min(1).max(2000),
  source: z.strictObject({
    provenance: z.enum(['synthetic', 'public']),
    title: z.string().max(300).nullable(),
    url: z.url().max(500).nullable(),
    doi: z.string().max(200).nullable(),
  }),
  noteDate: z.iso.date(),
  limitations: z.string().min(1).max(1000),
});
export type Note = z.infer<typeof noteSchema>;

// Parsing copies the fixture and bounds both collection size and response fields.
// This module has no file, network, transport, or model dependencies.
export function createNotebook(data: unknown) {
  const notes = z.array(noteSchema).min(1).max(15).parse(data);
  if (new Set(notes.map(n => n.id)).size !== notes.length) {
    throw new Error('Duplicate note IDs');
  }
  return {
    search(input: unknown) {
      const { query, limit } = searchInput.parse(input);
      const needle = query.toLowerCase();
      const matches = notes.filter(n =>
        [n.title, n.summary, ...n.topics].some(text => text.toLowerCase().includes(needle))
      ).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
      return {
        matches: matches.slice(0, limit).map(n => ({
          id: n.id, title: n.title, excerpt: n.summary.slice(0, 160),
          source: { ...n.source },
        })),
        total: matches.length,
      };
    },
    get(input: unknown) {
      const { id } = getInput.parse(input);
      const note = notes.find(n => n.id === id);
      return note
        ? { found: true as const, note: structuredClone(note) }
        : { found: false as const, note: null };
    },
  };
}
export type Notebook = ReturnType<typeof createNotebook>;
